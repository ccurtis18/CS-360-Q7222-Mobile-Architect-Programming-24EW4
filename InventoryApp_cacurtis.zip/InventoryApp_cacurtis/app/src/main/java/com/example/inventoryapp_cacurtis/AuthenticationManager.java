package com.example.inventoryapp_cacurtis;

import android.content.Context;
import android.content.SharedPreferences;

public class AuthenticationManager {

    private SharedPreferences sharedPreferences;

    public AuthenticationManager(Context context) {
        // Initialize SharedPreferences
        sharedPreferences = context.getSharedPreferences("user_credentials", Context.MODE_PRIVATE);
    }

    // Method to register a new user
    public void registerUser(String username, String password) {
        // Store username and password in SharedPreferences
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("username", username);
        editor.putString("password", password);
        editor.apply();
    }

    // Method to authenticate user login
    public boolean loginUser(String username, String password) {
        // Retrieve stored credentials
        String storedUsername = sharedPreferences.getString("username", "");
        String storedPassword = sharedPreferences.getString("password", "");

        // Check if entered credentials match stored credentials
        return username.equals(storedUsername) && password.equals(storedPassword);
    }
}
