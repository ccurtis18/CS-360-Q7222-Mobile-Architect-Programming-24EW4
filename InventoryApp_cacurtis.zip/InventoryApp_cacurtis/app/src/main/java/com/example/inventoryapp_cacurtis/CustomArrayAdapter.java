package com.example.inventoryapp_cacurtis;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Map;

public class CustomArrayAdapter extends ArrayAdapter<Map<String, String>> {

    private Context context;
    private ArrayList<Map<String, String>> items;

    public CustomArrayAdapter(Context context, int resource, ArrayList<Map<String, String>> items) {
        super(context, resource, items);
        this.context = context;
        this.items = items;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_layout, parent, false);
        }

        Map<String, String> item = items.get(position);

        TextView itemNameTextView = convertView.findViewById(R.id.itemNameTextView);
        TextView itemQuantityTextView = convertView.findViewById(R.id.itemQuantityTextView);

        itemNameTextView.setText(item.get("name"));
        itemQuantityTextView.setText(item.get("quantity"));

        return convertView;
    }
}
