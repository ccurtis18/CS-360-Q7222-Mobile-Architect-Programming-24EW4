package com.example.inventoryapp_cacurtis;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class InventoryActivity extends AppCompatActivity {

    private GridView gridView;
    private ArrayList<Map<String, String>> items;
    private ArrayAdapter<Map<String, String>> adapter;
    private int selectedItemPosition = -1;

    // Shared preferences
    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "inventory_prefs";
    private static final String KEY_ITEMS = "items";

    // Permission request code
    private static final int PERMISSION_REQUEST_SMS = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Request SMS permission
        requestSmsPermission();

        gridView = findViewById(R.id.gridViewInventory);
        items = new ArrayList<>();
        adapter = new CustomArrayAdapter(this, R.layout.item_layout, items);

        // Example items, you can replace this with actual inventory data
        addItem("Item 1", "10");
        addItem("Item 2", "20");
        addItem("Item 3", "30");

        // Initialize shared preferences
        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        // Load inventory data from shared preferences
        loadInventoryData();

        gridView.setAdapter(adapter);

        // Set click listener for the add item button
        Button addItemButton = findViewById(R.id.buttonAddItem);
        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onAddItemClick(v);
            }
        });

        // Set click listener for the delete item button
        Button deleteItemButton = findViewById(R.id.buttonDeleteItem);
        deleteItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onDeleteItemClick(v);
            }
        });

        // Set click listener for the logout button
        Button logoutButton = findViewById(R.id.buttonLogout);
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onLogoutClick(v);
            }
        });

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedItemPosition = position;
                editItem(position);
            }
        });
    }

    // Method to request SMS permission
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_SMS);
        }
    }

    // Method to handle permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("SMS", "SMS permission granted");
            } else {
                Log.d("SMS", "SMS permission denied");
            }
        }
    }

    // Method to add item to inventory
    public void onAddItemClick(View view) {
        // Show dialog to add new item
        showAddItemDialog();
    }

    // Method to delete item from inventory
    public void onDeleteItemClick(View view) {
        // Delete selected item from inventory
        if (selectedItemPosition != -1) {
            items.remove(selectedItemPosition);
            adapter.notifyDataSetChanged();
            selectedItemPosition = -1; // Reset selected position
            saveInventoryData();
        } else {
            Toast.makeText(this, "Please select an item to delete", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to edit item in inventory
    private void editItem(final int position) {
        final Map<String, String> item = items.get(position);
        AlertDialog.Builder builder = new AlertDialog.Builder(InventoryActivity.this);
        builder.setTitle("Edit Item");

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_edit_item, null);
        final EditText itemNameEditText = dialogView.findViewById(R.id.editTextItemName);
        final EditText quantityEditText = dialogView.findViewById(R.id.editTextQuantity);
        itemNameEditText.setText(item.get("name"));
        quantityEditText.setText(item.get("quantity"));
        builder.setView(dialogView);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String editedItemName = itemNameEditText.getText().toString().trim();
                String editedQuantity = quantityEditText.getText().toString().trim();
                item.put("name", editedItemName);
                item.put("quantity", editedQuantity);
                adapter.notifyDataSetChanged();
                saveInventoryData();
                dialog.dismiss();
            }
        });

        builder.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.setNegativeButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                items.remove(position);
                adapter.notifyDataSetChanged();
                saveInventoryData();
                dialog.dismiss();
            }
        });

        builder.show();
    }

    // Method to show dialog for adding new item
    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(InventoryActivity.this);
        builder.setTitle("Add New Item");

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_item, null);
        final EditText itemNameEditText = dialogView.findViewById(R.id.addTextItemName);
        final EditText quantityEditText = dialogView.findViewById(R.id.addTextQuantity);
        builder.setView(dialogView);

        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String itemName = itemNameEditText.getText().toString().trim();
                String quantity = quantityEditText.getText().toString().trim();
                addItem(itemName, quantity);
                adapter.notifyDataSetChanged();
                saveInventoryData();
                dialog.dismiss();
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    // Method to add item to the inventory
    private void addItem(String itemName, String quantity) {
        Map<String, String> item = new HashMap<>();
        item.put("name", itemName);
        item.put("quantity", quantity);
        items.add(item);
    }

    // Method to load inventory data from shared preferences
    private void loadInventoryData() {
        String itemsJson = sharedPreferences.getString(KEY_ITEMS, "");
        if (!itemsJson.isEmpty()) {
            items.clear();
            String[] itemsArray = itemsJson.split(",");
            for (String itemString : itemsArray) {
                String[] itemParts = itemString.split(":");
                if (itemParts.length == 2) {
                    Map<String, String> item = new HashMap<>();
                    item.put("name", itemParts[0]);
                    item.put("quantity", itemParts[1]);
                    items.add(item);
                }
            }
            adapter.notifyDataSetChanged();
        }
    }

    // Method to save inventory data to shared preferences
    private void saveInventoryData() {
        StringBuilder itemsBuilder = new StringBuilder();
        for (Map<String, String> item : items) {
            itemsBuilder.append(item.get("name")).append(":").append(item.get("quantity")).append(",");
        }
        String itemsJson = itemsBuilder.toString();
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_ITEMS, itemsJson);
        editor.apply();
    }

    // Method to handle logout button click
    public void onLogoutClick(View view) {
        // Navigate back to the login screen
        Intent intent = new Intent(InventoryActivity.this, MainActivity.class);
        startActivity(intent);
        finish(); // Finish the current activity to prevent going back to it
    }
}
